Auteurs :
Alhabaj Mahmod
Belda Tom
Dakroub MohamadAli

Les deux programmes sont deux projets differents, leurs sources sont donc bien séparées. Chaque programme à donc 
ses classes et ses fichiers de sauvegarde. 
Dans les deux projets, la classe principale est "MainController". C'est dans cette classe que ce trouve le main.

Les classes sont séparées dans 3 packages, le package "model" qui contient la structure de données du programme,
le package "view" qui contient toutes les classes d'affichage du programme et le package "controller" qui fait les
opérations et gère la liaison entre le model et la view dans la plupart des cas.
De plus, dans le projet "central", nous avons ajouté une classe de test JUNIT pour tester les différentes classes du package
"model".

-Toutes les fonctionnalites principale, ainsi que optionnelles ont etaient implemente dans l'application centrale et la pointeuse. 
	L'ensemble du code ainsi que la JavaDoc est en anglais egalement.

Informations importantes : 
- Dans l'onglet workers, les informations des workers sont modifiables. Pour confirmer une modification, 
  il suffit d'appuyer sur la touche entrée.

- Les id des worker sont forcement composé de 5 chiffres.

- Si vous corrigez le projet pendant le weekend, vous ne pourrez pas pointer à partir de la pointeuse (Solution = changer date 
													de de l'ordinateur)

- Il n'y a pas de contraintes sur l'ordre de lancement des programmes. Il suffit d'importer dans deux projets eclipse 
  séparés et lance l'un puis l'autre. Il y'a la possibilité de lancer plusieurs pointeuses, mais un "central" peut être executé à la fois.

- Si erreur réseau dans l'application centrale -> restart l'appli ou changer le port via l'onglet parametres. 

- Les deux applications doivent avoir le même port dans l'onglet parametres.

- Le serveur se lance par defaut sur le port 7700 avec l'adresse 127.0.0.1 .


- Nous n'avons pas fourni de methode stub (un main brouillon) car nous avons reussi a implementer la totalite des fonctionnalites demandees.
- Nous avons neanmoins fourni dans l'application une base de donnees remplie (elle est automatiquement importe et sauvgarde 
										dans l'application central: assets/dataBase.ser)
	que vous pourrez manipuler (ajouts, modifications..etc)



-Merci de se referer a la documentation pour l'utilisation de la fonctionnalitee (add entry from file) dans l'onglet Workers. 

-Un fichier "ImportFile-Dakroub_Worker.txt" vous est fourni pour la tester. 
Pour cela, 
 il suffit d'aller dans l'onglet "workers"->"add entry from file" -> et choisir le fichier. Vous pourrez ensuite consulter le travailleur 
 "MohamadAli Dakroub" (car son id est de 10005)  dans le departement "developpement" et voir ses donnees importes et mis à jour.








